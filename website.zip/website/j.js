function compare()
{
    let num=2;
    let b=2;
    if (a==b)
        return true;
    else
        return false;
}