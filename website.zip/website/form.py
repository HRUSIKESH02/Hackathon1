if a==20 and b==10:
    print("yoo")